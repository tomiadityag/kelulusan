export const ENV = {
    base : process.env.BASE_URL
}